repeat
  f()
until false
